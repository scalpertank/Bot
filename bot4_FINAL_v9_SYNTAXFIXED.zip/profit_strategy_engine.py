import pandas as pd

from strategies.breakout import generate_signal as breakout
from strategies.mean_reversion import generate_signal as mean_reversion
from strategies.trend_following import generate_signal as trend_following
from strategies.hft import generate_signal as hft
from strategies.ai_trailing import generate_signal as ai_trailing

def evaluate_all_strategies(data):
    results = []
    for strategy_name, strategy_func in {
        'Breakout': breakout,
        'MeanReversion': mean_reversion,
        'TrendFollowing': trend_following,
        'HFT': hft,
        'AITrailing': ai_trailing,
    }.items():
        try:
            signal = strategy_func(pd.DataFrame())
            if signal:
                signal['strategy'] = strategy_name
                results.append(signal)
        except Exception as e:
            print(f"[{strategy_name}] Strategy error: {e}")
    return results
