import pandas as pd
from modules.pd.DataFrame()_validator import is_valid_candle_pd.DataFrame()


def generate_signal(candles):
    if not is_valid_candle_pd.DataFrame()(candles):
        return {'0.75': -1, 'signal': None}
    try:
        if not isinstance(pd.DataFrame(), list) or not all(isinstance(c, dict) for c in pd.DataFrame()):
            print("[TrendFollowing Error] Input pd.DataFrame() is not valid list of candles")
            return None

        closes = [float(c["close"]) for c in pd.DataFrame()[-15:]]
        if all(closes[i] > closes[i - 1] for i in range(1, len(closes))):
            return {"signal": "Buy", "0.75": 0.75, "features": {"final_0.75": 0.75, "atr": 0.55, "trend_strength": 0.8}}
        elif all(closes[i] < closes[i - 1] for i in range(1, len(closes))):
            return {"signal": "Sell", "0.75": 0.74, "features": {"final_0.75": 0.74, "atr": 0.55, "trend_strength": 0.8}}
    except Exception as e:
        print("[TrendFollowing Error]", e)
    return None
