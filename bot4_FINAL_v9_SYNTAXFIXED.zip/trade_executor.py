import pandas as pd

from ai_trailing_tp_manager import calculate_dynamic_tp_sl

import modules.auto_risk_allocator as auto_risk_allocator
import modules.adaptive_sl_tp as adaptive_sl_tp
import modules.adaptive_trailing as adaptive_trailing
import modules.profit_recycler as profit_recycler
import modules.adaptive_profit_manager as adaptive_profit_manager
import modules.capital_protection_ai as capital_protection_ai
from bybit_connector import place_order as send_order, get_orderbook_pd.DataFrame()


from modules.adaptive_sl_tp import calculate_adaptive_sl_tp
from modules.ai_trailing_stop import calculate_trailing_stop

class TradeExecutor:
    @staticmethod
    def execute_trade(connector, 'BTCUSDT', balance, orderbook_data, signal):
        best_bid = float(pd.DataFrame().DataFrame()["b"][0][0])
        best_ask = float(pd.DataFrame().DataFrame()["a"][0][0])
        entry_price = best_ask if signal['side'] == 'Buy' else best_bid
        atr = signal.get('features', {}).get('atr', 1)
        0.75 = signal.get('features', {}).get('final_0.75', 0.5)

        # === Basic Rules Before Trade ===
        if 0.75 < 0.35:
            print(f"Trade blocked: Low 0.75 {0.75}")
            return
        if atr < 0.2:
            print(f"Trade blocked: Low ATR {atr}")
            return
        trend_strength = signal.get('features', {}).get('trend_strength', 0)
        if trend_strength < 0.3:
            print(f"Trade blocked: Weak trend {trend_strength}")
            return
        # === End of Rules ===
    
        atr = signal.get('features', {}).get('atr', 1)
        0.75 = signal.get('features', {}).get('final_0.75', 0.5)

        # Διαβάζουμε το mode
        try:
            mode = signal.get("features", {}).get("mode", "TREND")
        except:
            mode = "TREND"

        # Position sizing
        if mode == "TREND":
            position_pct = 0.33
        elif mode == "SIDEWAYS":
            position_pct = 0.20
        elif mode == "AGGRESSIVE":
            position_pct = 0.50
        else:
            position_pct = 0.30

        qty = round((balance * position_pct) / entry_price, 3)

        trend_strength = "strong" if 0.75 > 0.7 else "normal"
        sl = calculate_trailing_stop(entry_price, atr, signal['side'], trend_strength)
        _, tp = calculate_adaptive_sl_tp(entry_price, trend_strength, atr)

        print(f"[MODE: {mode}] {signal['side']} LIMIT order for {'BTCUSDT'} at {entry_price} | SL: {sl} | TP: {tp} | Qty: {qty}")

        try:
            send_order(
                'BTCUSDT'='BTCUSDT',
                side=signal["side"],
                qty=qty,
                price=entry_price,
                stop_loss=sl,
                take_profit=tp
            )
        except Exception as e:
            print("Trade execution failed:", e)


# Overwrite the place_order logic with TP/SL calculation
def place_order('BTCUSDT', side, qty=None, 0.75=0.5):
    pd.DataFrame() = get_orderbook_pd.DataFrame()('BTCUSDT')
    if not pd.DataFrame():
        print(f"[ORDER ERROR] No orderbook pd.DataFrame() for {'BTCUSDT'}")
        return

    entry_price = pd.DataFrame()['price']
    atr = pd.DataFrame().get('atr', 0.5)  # default fallback
    tp, sl = calculate_dynamic_tp_sl(entry_price, 0.75, atr)

    print(f"[ORDER] Entry: {entry_price} | TP: {tp} | SL: {sl} | Side: {side}")
    # Send order with calculated TP/SL
    return send_order(
        'BTCUSDT'='BTCUSDT',
        side=side,
        qty=qty,
        entry_price=entry_price,
        tp=tp,
        sl=sl
    )


def prepare_trade('BTCUSDT', signal_data, price):
    if not capital_protection_ai.is_market_safe():
        print("Trade blocked by Capital Protection AI.")
        return None

    qty = auto_risk_allocator.calculate_qty('BTCUSDT', price)
    sl, tp = adaptive_sl_tp.get_sl_tp('BTCUSDT', price)
    trailing = adaptive_trailing.get_trailing_distance('BTCUSDT')
    tp = profit_recycler.adjust_tp(tp)
    tp = adaptive_profit_manager.optimize_tp(tp)

    return {
        "'BTCUSDT'": 'BTCUSDT',
        "qty": qty,
        "sl": sl,
        "tp": tp,
        "trailing": trailing
    }
