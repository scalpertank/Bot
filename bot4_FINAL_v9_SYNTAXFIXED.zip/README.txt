
Perfect.scalper AI Brain v12.0 – Full Auto Scalping Bot
========================================================

Οδηγίες Εκκίνησης:
-------------------
1. Βεβαιώσου ότι έχεις εγκατεστημένη Python 3.10+
2. Εγκατέστησε τα dependencies:
   pip install -r requirements.txt

3. Συμπλήρωσε το αρχείο config.py με τα δικά σου API_KEY και API_SECRET από Bybit.

4. Τρέξε το bot:
   python main.py


Λειτουργίες:
------------
- Adaptive Trailing Stop & Risk
- AI Score Filtering & Trade Validation
- Orderbook Intelligence (bid dominance, spoofing detection)
- Dynamic Position Sizing
- Auto Profit Recycling σε sniper trades
- Daily Report με κέρδη, winrate, symbols
- Auto feedback adjustment σε thresholds


Αρχεία Logs:
-------------
- trades_log.csv : καταγράφει όλα τα trades
- reports/report_YYYY-MM-DD.txt : αναφορά απόδοσης ημέρας

Προτεινόμενα:
-------------
- Τρέξε το bot σε VPS για 24/7 λειτουργία
- Παρακολούθησε winrate κάθε 3 ημέρες
- Χρησιμοποίησε μόνο paper/live test accounts πριν πας σε κανονικό κεφάλαιο

Καλή Επιτυχία και Κέρδη!
