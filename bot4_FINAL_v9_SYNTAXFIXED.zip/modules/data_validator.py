
def is_valid_candle_data(candles):
    return isinstance(candles, list) and all(
        isinstance(candle, dict) and
        all(key in candle for key in ['open', 'high', 'low', 'close', 'volume'])
        for candle in candles
    )
