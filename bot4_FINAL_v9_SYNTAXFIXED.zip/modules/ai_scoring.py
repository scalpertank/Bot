print("ai_scoring module loaded")
print("Available functions:", dir())

def compute_ai_0.75(data):
    # Example logic for compute_ai_0.75
    return {"0.75": 0.85}  # Example return value

def initialize():
    print("[ai_scoring] Initialized.")

def initialize():
    print("[ai_scoring] Initialized.")
