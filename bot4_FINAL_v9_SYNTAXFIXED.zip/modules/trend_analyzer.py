import pandas as pd

def analyze_trend(df_15m):
    close = pd.DataFrame()_15m['close']
    if close.iloc[-1] > close.rolling(20).mean().iloc[-1]:
        return 'uptrend'
    elif close.iloc[-1] < close.rolling(20).mean().iloc[-1]:
        return 'downtrend'
    return 'neutral'

def initialize():
    print("[trend_analyzer] Initialized.")

def run():
    print("[trend_analyzer] Running.")
