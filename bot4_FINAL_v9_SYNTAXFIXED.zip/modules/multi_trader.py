
def initialize():
    print("[multi_trader] Initialized.")

def run():
    print("[multi_trader] Running default logic.")
