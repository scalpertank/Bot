
def calculate_trailing_stop(entry_price, atr, direction, strength="normal"):
    if direction == "Buy":
        if strength == "strong":
            return round(entry_price - 1.0 * atr, 4)
        else:
            return round(entry_price - 1.5 * atr, 4)
    elif direction == "Sell":
        if strength == "strong":
            return round(entry_price + 1.0 * atr, 4)
        else:
            return round(entry_price + 1.5 * atr, 4)
    return entry_price
