
class SymbolGrader:
    GOOD_SYMBOLS = [
        "BTCUSDT", "ETHUSDT", "SOLUSDT", "AVAXUSDT", "INJUSDT", "APTUSDT", "OPUSDT"
    ]
    @staticmethod
    def is_approved('BTCUSDT'):
        return 'BTCUSDT' in SymbolGrader.GOOD_SYMBOLS
