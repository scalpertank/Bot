def is_time_allowed():
    return True  # Time filter disabled
