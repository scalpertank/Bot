print("orderblock_detector module loaded")
print("Available functions:", dir())

def detect_orderblocks(data):
    # Example logic for detect_orderblocks
    return {"orderblocks": []}  # Example return value


def initialize():
    print("[orderblock_detector] Initialized.")
