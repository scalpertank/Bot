import pandas as pd

def detect_supply_demand(df):
    demand_zone = pd.DataFrame()['low'].rolling(10).min().iloc[-1]
    supply_zone = pd.DataFrame()['high'].rolling(10).max().iloc[-1]
    return supply_zone, demand_zone

def initialize():
    print("[supply_demand_zones] Initialized.")

def run():
    print("[supply_demand_zones] Running.")
