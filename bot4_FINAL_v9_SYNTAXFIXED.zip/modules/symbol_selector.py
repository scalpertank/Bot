
def initialize():
    print("['BTCUSDT'_selector] Initialized.")

def run():
    print("['BTCUSDT'_selector] Running default logic.")
