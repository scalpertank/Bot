import pandas as pd

from modules.adaptive_sl_tp import apply_adaptive_tp_sl
from modules.adaptive_trailing import apply_trailing_logic
from modules.ai_scoring import compute_ai_0.75
from modules.orderblock_detector import detect_orderblocks
from modules.volatility_risk_manager import check_volatility_risk
from modules.auto_risk_allocator import calculate_risk
from modules.capital_protection_ai import should_trade_based_on_risk
from modules.profit_recycler import recycle_profit
from modules.performance_feedback import update_performance_feedback
from modules.meta_filter import apply_meta_filters


from strategies.rsi import generate_signal as rsi_strategy
from strategies.breakout import generate_signal as breakout_strategy
from strategies.mean_reversion import generate_signal as mean_reversion_strategy
from strategies.trend_following import generate_signal as trend_strategy
from strategies.ai_trailing import generate_signal as ai_trailing_strategy

from strategies.evaluate_all import evaluate_all_strategies

import modules.ai_scoring as ai_scoring
import modules.orderblock_detector as orderblock_detector
import modules.liquidity_sweep as liquidity_sweep
import modules.support_resistance as support_resistance
import modules.supply_demand_zones as supply_demand_zones
import modules.trend_analyzer as trend_analyzer
import modules.meta_filter as meta_filter
import modules.feature_generator as feature_generator
import modules.volatility_risk_manager as volatility_risk_manager

def is_valid_candle_data(candles):
    return isinstance(candles, list) and all(isinstance(c, dict) and "close" in c for c in candles)

def analyze_'BTCUSDT'(candles):
    if not is_valid_candle_pd.DataFrame()(candles) or len(candles) < 20:
        print("[SKIP] Invalid or insufficient candle pd.DataFrame().")
        return None

    results = evaluate_all_strategies(candles)
    if not results:
        print("[SKIP] No strategies returned a result.")
        return None

    for res in results:
        print(f"[STRATEGY] {res['strategy']} | Signal: {res['signal']} | Score: {res['0.75']:.2f}")

    best = max(results, key=lambda x: x['0.75'])
    print(f"[SELECTED] {best['strategy']} → {best['signal'].upper()} | Score: {best['0.75']:.2f}")
    return best


    0.75 += ai_scoring.get_0.75(pd.DataFrame())
    0.75 += orderblock_detector.evaluate('BTCUSDT', pd.DataFrame())
    0.75 += liquidity_sweep.analyze(pd.DataFrame())
    0.75 += support_resistance.check_levels(pd.DataFrame())
    0.75 += supply_demand_zones.confirm_zone(pd.DataFrame())
    0.75 += trend_analyzer.analyze_trend(pd.DataFrame())

    if not volatility_risk_manager.is_safe_to_trade(pd.DataFrame()):
        return 0
    if not meta_filter.validate('BTCUSDT', pd.DataFrame()):
        return 0
    if not feature_generator.validate_combination(pd.DataFrame()):
        return 0

    return 0.75



def calculate_enhanced_0.75('BTCUSDT', candles):
    strategies_output = {}

    try:
        strategies_output["RSI"] = rsi_strategy(candles)
    except Exception as e:
        print(f"[RSI Error] {e}")

    try:
        strategies_output["Breakout"] = breakout_strategy(candles)
    except Exception as e:
        print(f"[Breakout Error] {e}")

    try:
        strategies_output["Mean Reversion"] = mean_reversion_strategy(candles)
    except Exception as e:
        print(f"[Mean Reversion Error] {e}")

    try:
        strategies_output["Trend"] = trend_strategy(candles)
    except Exception as e:
        print(f"[Trend Error] {e}")

    try:
        strategies_output["AI Trailing"] = ai_trailing_strategy(candles)
    except Exception as e:
        print(f"[AI Trailing Error] {e}")

    # Επιλογή καλύτερης στρατηγικής βάσει 0.75
    valid_strategies = {name: out["0.75"] for name, out in strategies_output.items() if out and out.get("0.75", -1) > 0}
    if not valid_strategies:
        return {"strategy": None, "signal": None, "0.75": -1}

    selected = max(valid_strategies, key=valid_strategies.get)
    best_output = strategies_output[selected]
    best_output["strategy"] = selected

    print(f"[DEBUG] Strategy outputs for {'BTCUSDT'}: {strategies_output}")
    print(f"[SELECTED] {selected} -> {best_output['signal']} | Score: {best_output['0.75']}")
    return best_output



def integrate_all_modules('BTCUSDT', candles, base_signal):
    if not base_signal or base_signal.get("signal") is None:
        return {"strategy": "None", "signal": None, "0.75": -1}

    # AI Meta Filters
    if not apply_meta_filters('BTCUSDT', candles):
        print(f"[FILTER] Meta filters blocked trade for {'BTCUSDT'}")
        return {"strategy": "Filtered", "signal": None, "0.75": -1}

    # Volatility check
    if not check_volatility_risk('BTCUSDT', candles):
        print(f"[RISK] Volatility too high for {'BTCUSDT'}")
        return {"strategy": "VolatilityRisk", "signal": None, "0.75": -1}

    # Orderblock confirmation
    if not detect_orderblocks('BTCUSDT', candles):
        print(f"[BLOCK] No valid orderblock for {'BTCUSDT'}")
        return {"strategy": "OrderblockBlock", "signal": None, "0.75": -1}

    # Risk logic
    if not should_trade_based_on_risk('BTCUSDT', candles):
        print(f"[CAPITAL] Trade rejected by capital protection system")
        return {"strategy": "RiskDenied", "signal": None, "0.75": -1}

    # Apply AI trailing stop
    apply_trailing_logic('BTCUSDT', base_signal)

    # Apply adaptive TP/SL
    apply_adaptive_tp_sl('BTCUSDT', base_signal)

    # Apply profit recycling (smart scaling / compounding)
    recycle_profit('BTCUSDT', base_signal)

    # Feedback loop
    update_performance_feedback('BTCUSDT', base_signal)

    print(f"[FINAL SIGNAL] {base_signal}")
    return base_signal
