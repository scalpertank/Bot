import requests

url = "https://api.bybit.com/v5/market/klines"
params = {
    "category": "linear",
    "'BTCUSDT'": "BTCUSDT",
    "interval": "5m",
    "limit": 5
}

response = requests.get(url, params=params)
print("Status code:", response.status_code)
print("Text:", response.text)