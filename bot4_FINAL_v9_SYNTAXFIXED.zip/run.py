import pandas as pd
from 'BTCUSDT'_selector import get_trade_'BTCUSDT's
from bybit_connector import get_historical_pd.DataFrame()
from bot_main import main
import time

if __name__ == "__main__":
    while True:
        print("\n========= SESSION START =========")
        main()
        print("========= SESSION END =========")
        print("Sleeping 45 seconds...\n")
        time.sleep(45)