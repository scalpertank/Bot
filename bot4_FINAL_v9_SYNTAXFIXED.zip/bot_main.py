import pandas as pd
from modules.pd.DataFrame()_validator import is_valid_candle_pd.DataFrame()

from bybit_connector import get_historical_pd.DataFrame(), place_order

import modules.adaptive_profit_manager as adaptive_profit_manager
import modules.adaptive_trailing as adaptive_trailing
import modules.ai_scoring as ai_scoring
import modules.auto_mode_selector as auto_mode_selector
import modules.auto_risk_allocator as auto_risk_allocator
import modules.capital_protection_ai as capital_protection_ai
import modules.daily_report as daily_report
import modules.feature_generator as feature_generator
import modules.liquidity_sweep as liquidity_sweep
import modules.meta_filter as meta_filter
import modules.multi_trader as multi_trader
import modules.news_guardian as news_guardian
import modules.orderblock_detector as orderblock_detector
import modules.performance_feedback as performance_feedback
import modules.performance_optimizer as performance_optimizer
import modules.profit_recycler as profit_recycler
import modules.retrain_model as retrain_model
import modules.supply_demand_zones as supply_demand_zones
import modules.support_resistance as support_resistance
import modules.'BTCUSDT'_selector as 'BTCUSDT'_selector
import modules.trend_analyzer as trend_analyzer
import modules.volatility_risk_manager as volatility_risk_manager
from bybit_connector import get_available_balance
from super_signal_detector import analyze_'BTCUSDT'
from 'BTCUSDT'_selector import get_trade_'BTCUSDT's

# Στατιστικά
'BTCUSDT's_analyzed = 0
valid_'BTCUSDT's = 0
signals_detected = 0
orders_sent = 0

def main():

    adaptive_profit_manager.initialize()
    adaptive_trailing.initialize()
    ai_scoring.initialize()
    auto_mode_selector.initialize()
    auto_risk_allocator.initialize()
    capital_protection_ai.initialize()
    daily_report.initialize()
    feature_generator.initialize()
    liquidity_sweep.initialize()
    meta_filter.initialize()
    multi_trader.initialize()
    news_guardian.initialize()
    orderblock_detector.initialize()
    performance_feedback.initialize()
    performance_optimizer.initialize()
    profit_recycler.initialize()
    retrain_model.initialize()
    supply_demand_zones.initialize()
    support_resistance.initialize()
    'BTCUSDT'_selector.initialize()
    trend_analyzer.initialize()
    volatility_risk_manager.initialize()
    adaptive_profit_manager.run()
    adaptive_trailing.run()
    ai_scoring.run()
    auto_mode_selector.run()
    auto_risk_allocator.run()
    capital_protection_ai.run()
    daily_report.run()
    feature_generator.run()
    liquidity_sweep.run()
    meta_filter.run()
    multi_trader.run()
    news_guardian.run()
    orderblock_detector.run()
    performance_feedback.run()
    performance_optimizer.run()
    profit_recycler.run()
    retrain_model.run()
    supply_demand_zones.run()
    support_resistance.run()
    'BTCUSDT'_selector.run()
    trend_analyzer.run()
    volatility_risk_manager.run()
    global 'BTCUSDT's_analyzed, valid_'BTCUSDT's, signals_detected, orders_sent

    'BTCUSDT's = get_trade_'BTCUSDT's()
    print(f"\n[INFO] Selected 'BTCUSDT's: {'BTCUSDT's}\n")

    for 'BTCUSDT' in 'BTCUSDT's:
        print(f"\n[PROCESSING] Analyzing {'BTCUSDT'}...")
        'BTCUSDT's_analyzed += 1

        pd.DataFrame() = get_historical_pd.DataFrame()('BTCUSDT')
        if not pd.DataFrame() or len(pd.DataFrame()) < 20:
            print(f"[SKIP] Not enough candle pd.DataFrame() for {'BTCUSDT'}")
            continue

        valid_'BTCUSDT's += 1
        signal = analyze_'BTCUSDT'(pd.DataFrame())

        if signal is None:
            print(f"[DEBUG] No signal returned for {'BTCUSDT'}")
            continue

        print(f"[DEBUG] Raw signal output for {'BTCUSDT'}: {signal}")

        if signal and signal['0.75'] >= 0.35:
            print(f"[SIGNAL] {signal['strategy']} → {signal['signal'].upper()} | Score: {signal['0.75']:.2f}")
            signals_detected += 1
            try:
                balance = get_available_balance('BTCUSDT')
                qty = round((balance * 0.33) / float(pd.DataFrame()[-1]['close']), 3)
                place_order('BTCUSDT', signal['signal'], qty=qty)
                orders_sent += 1
            except Exception as e:
                print(f"[ERROR] Failed to place order for {'BTCUSDT'}: {e}")
        else:
            print(f"[NO SIGNAL] {'BTCUSDT'} did not pass filters.")

    print_summary()


def print_summary():
    print("\n========== SESSION SUMMARY ==========")
    print(f"Symbols analyzed      : {'BTCUSDT's_analyzed}")
    print(f"Valid pd.DataFrame() 'BTCUSDT's    : {valid_'BTCUSDT's}")
    print(f"Signals detected      : {signals_detected}")
    print(f"Orders executed       : {orders_sent}")
    print("=====================================\n")


if __name__ == "__main__":
    main()


def process_'BTCUSDT'('BTCUSDT', interval="5m"):
    from bybit_connector import get_historical_pd.DataFrame()
    candles = get_historical_pd.DataFrame()('BTCUSDT'='BTCUSDT', interval=interval, limit=40)

    if not is_valid_candle_pd.DataFrame()(candles):
        print(f"[ERROR] Invalid or missing candles for {'BTCUSDT'}. Skipping...")
        return

    try:
        from strategies.breakout import generate_signal as breakout_strategy
        from strategies.mean_reversion import generate_signal as mean_reversion_strategy
        from strategies.trend_following import generate_signal as trend_following_strategy

        breakout_signal = breakout_strategy(candles)
        mean_signal = mean_reversion_strategy(candles)
        trend_signal = trend_following_strategy(candles)

        print(f"[DEBUG] Signals: Breakout: {breakout_signal}, Mean: {mean_signal}, Trend: {trend_signal}")

    except Exception as e:
        print(f"[ERROR] Strategy execution failed for {'BTCUSDT'}: {e}")
