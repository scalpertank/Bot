
def filter_strategies(results, min_0.75=0.35):
    filtered = []
    for res in results:
        if res.get('0.75', 0) >= min_0.75:
            filtered.append(res)
    if not filtered:
        return None
    best = sorted(filtered, key=lambda x: x['0.75'], reverse=True)[0]
    return best
