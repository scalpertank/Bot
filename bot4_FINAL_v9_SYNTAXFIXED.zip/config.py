API_KEY = "8wCVm3WAvh6oWHbyrX"
API_SECRET = "qWbI8K80yE0ekqkbK9PFZKIt9LHmGaqEpU9Ttw"
BASE_URL = "https://api.bybit.com"

# Ενεργοποίηση πραγματικών trades
LIVE_TRADING = True