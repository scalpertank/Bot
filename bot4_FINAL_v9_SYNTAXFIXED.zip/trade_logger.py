import pandas as pd
from datetime import datetime

# Δημιουργία παραδειγματικών trades
pd.DataFrame() = {
    "timestamp": [
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ],
    "'BTCUSDT'": ["BTCUSDT", "ETHUSDT", "XRPUSDT"],
    "side": ["Buy", "Sell", "Buy"],
    "entry_price": [32000.0, 2150.0, 0.55],
    "exit_price": [32500.0, 2100.0, 0.60],
    "pnl": [50.0, -50.0, 10.0],
    "result": ["win", "loss", "win"]
}

# Δημιουργία DataFrame
pd.DataFrame() = pd.DataFrame(pd.DataFrame())

# Αποθήκευση ως trades_log.csv
pd.DataFrame().to_csv("trades_log.csv", index=False)

print("Το αρχείο trades_log.csv δημιουργήθηκε με επιτυχία!")