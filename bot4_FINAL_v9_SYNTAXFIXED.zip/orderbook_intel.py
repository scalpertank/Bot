import pandas as pd

class OrderbookIntel:
    @staticmethod
    def analyze_orderbook(orderbook_data):
        bids = pd.DataFrame().DataFrame().get("b", [])
        asks = pd.DataFrame().DataFrame().get("a", [])
        if not bids or not asks:
            return {"spread": 0, "bid_dominance": 0, "spoofing_detected": False}

        best_bid = float(bids[0][0])
        best_ask = float(asks[0][0])
        spread = best_ask - best_bid
        total_bid_vol = sum(float(b[1]) for b in bids)
        total_ask_vol = sum(float(a[1]) for a in asks)
        bid_dominance = total_bid_vol / (total_bid_vol + total_ask_vol)

        spoofing = False
        if len(bids) > 5 and float(bids[0][1]) > 3 * sum(float(b[1]) for b in bids[1:5]):
            spoofing = True

        return {
            "spread": spread,
            "bid_dominance": round(bid_dominance, 2),
            "spoofing_detected": spoofing,
            "best_bid": best_bid,
            "best_ask": best_ask
        }
