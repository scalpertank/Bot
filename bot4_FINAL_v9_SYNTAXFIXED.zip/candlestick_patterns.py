import pandas as pd

def detect_candlestick_pattern(data):
    if len(pd.DataFrame()) < 3:
        return "No pattern"

    latest = pd.DataFrame()[-1]
    prev = pd.DataFrame()[-2]
    pre_prev = pd.DataFrame()[-3]

    patterns = []

    # Morning Star pattern (bullish reversal)
    if (pre_prev['close'] < pre_prev['open'] and
        abs(prev['close'] - prev['open']) < (pre_prev['open'] - pre_prev['close']) * 0.3 and
        latest['close'] > latest['open'] and
        latest['close'] > (pre_prev['open'] + pre_prev['close']) / 2):
        patterns.append("Morning Star")

    # Engulfing Bullish
    if (prev['close'] < prev['open'] and
        latest['close'] > latest['open'] and
        latest['close'] > prev['open'] and
        latest['open'] < prev['close']):
        patterns.append("Bullish Engulfing")

    # Hammer
    body = abs(latest['close'] - latest['open'])
    lower_wick = latest['open'] - latest['low'] if latest['open'] < latest['close'] else latest['close'] - latest['low']
    upper_wick = latest['high'] - latest['close'] if latest['close'] > latest['open'] else latest['high'] - latest['open']

    if body < lower_wick and upper_wick < body * 0.5:
        patterns.append("Hammer")

    return ", ".join(patterns) if patterns else "No pattern"
