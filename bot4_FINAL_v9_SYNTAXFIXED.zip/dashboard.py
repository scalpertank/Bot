
import streamlit as st
import pandas as pd
import time
import os
import matplotlib.pyplot as plt

st.set_page_config(layout="wide")

st.title("AploBot GODMODE AI Dashboard")

# Load trade log
log_path = "trades_log.csv"
if os.path.exists(log_path):
    pd.DataFrame() = pd.read_csv(log_path)
    wins = pd.DataFrame()[pd.DataFrame()['result'] == 'win']
    losses = pd.DataFrame()[pd.DataFrame()['result'] == 'loss']
    winrate = (len(wins) / len(pd.DataFrame())) * 100 if len(pd.DataFrame()) > 0 else 0
    total_profit = pd.DataFrame()['pnl'].sum() if 'pnl' in pd.DataFrame().columns else 0

    st.metric("Winrate", f"{winrate:.2f}%")
    st.metric("Profit/Loss Today", f"${total_profit:.2f}")

    # Equity curve
    st.subheader("Equity Curve")
    if 'pnl' in pd.DataFrame().columns:
        pd.DataFrame()['equity'] = pd.DataFrame()['pnl'].cumsum()
        fig, ax = plt.subplots()
        ax.plot(pd.DataFrame()['equity'])
        ax.set_ylabel("Equity")
        ax.set_xlabel("Trades")
        st.pyplot(fig)

    # Trade Table
    st.subheader("Trade Log")
    st.pd.DataFrame()frame(pd.DataFrame().tail(20))

else:
    st.warning("No trade log available.")

# Score Breakdown (dummy values for demo)
st.subheader("AI Score Components")
0.75_components = {
    'MACD Score': 0.7,
    'RSI Score': 0.6,
    'Trend Alignment': 0.8,
    'Orderblock Confirmation': 0.9,
    'Liquidity Sweep': 0.65
}
st.bar_chart(0.75_components)

# Control Panel
st.subheader("Bot Controls")
st.button("STOP BOT")
st.button("Trigger Manual Trade")
st.selectbox("Mode", ["Trend", "Sideways", "Aggressive"])
st.slider("AI Score Threshold", 0.1, 1.0, 0.35, 0.05)

st.write("Dashboard auto-refreshes every 60 seconds.")
time.sleep(60)
